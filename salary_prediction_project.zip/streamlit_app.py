# streamlit_app.py
# Simple Streamlit app to load the trained model and predict salary for user input.

import streamlit as st
import joblib
import numpy as np
import pandas as pd
from pathlib import Path

MODEL_PATH = Path("saved_model.joblib")

st.set_page_config(page_title="Salary Predictor", layout="centered")

st.title("Salary Prediction for Company X (Demo)")
st.markdown("Enter candidate details to get a predicted fair salary (demo).")

# Load model
if not MODEL_PATH.exists():
    st.warning("Model not found. Run `python train_and_evaluate.py` to train and create the model.")
else:
    model = joblib.load(MODEL_PATH)

    # Input form
    with st.form("candidate_form"):
        experience = st.number_input("Experience (years)", min_value=0.0, max_value=50.0, value=3.0, step=0.5)
        education = st.selectbox("Education", ["Bachelor", "Master", "PhD"])
        role = st.selectbox("Role", ["Engineer", "Analyst", "Manager", "Senior Engineer", "Data Scientist"])
        skills = st.slider("Skills Score (0-10)", 0, 10, 6)
        communication = st.slider("Communication Score (0-10)", 0, 10, 6)
        location = st.selectbox("Location", ["CityA", "CityB", "CityC"])
        submitted = st.form_submit_button("Predict Salary")

    if submitted:
        input_df = pd.DataFrame([{
            "Experience": experience,
            "Education": education,
            "Role": role,
            "Skills_Score": skills,
            "Communication_Score": communication,
            "Location": location
        }])
        pred = model.predict(input_df)[0]
        st.success(f"Predicted fair salary (approx): ₹{pred:,.0f}")
        st.write("**Note:** This is a demo. Train the model on company data for production use.")
