# Salary Prediction Model Using Machine Learning

## Project Title
Salary Prediction Model Using Machine Learning

## Domain
Machine Learning / Data Science / Human Resources Analytics

## Project Overview
To ensure there is no discrimination between employees, this project builds a machine learning model that predicts a fair and consistent salary for a new employee based on their profile — minimizing human bias and judgment in salary decisions.

## Objectives
- Develop a regression ML model that predicts employee salary.
- Minimize manual bias in salary determination.
- Visualize and analyze feature influence on salary.
- Optionally deploy a simple web interface for HR use.

## Dataset (sample)
A sample CSV `employee_salary_data.csv` is included with synthetic data. Key columns:
- Experience: years (numeric)
- Education: Bachelor's/Master/PhD (categorical)
- Role: job title (categorical)
- Skills_Score: 0-10 (numeric)
- Communication_Score: 0-10 (numeric)
- Location: city/region (categorical)
- Gender: (for fairness analysis only)
- Salary: target variable (numeric)

## Files in this package
- `README.md` - this document (project report)
- `employee_salary_data.csv` - sample dataset (synthetic) for practice
- `train_and_evaluate.py` - Python script to train models and evaluate
- `streamlit_app.py` - Streamlit app to interact with the model (uses saved model file)
- `requirements.txt` - Python dependencies
- `saved_model.joblib` - a placeholder; run `train_and_evaluate.py` to create it
- `notes.txt` - short guidance for using the package

---

## How to run (quick)
1. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate    # or venv\Scripts\activate on Windows
   pip install -r requirements.txt
   ```

2. Train model:
   ```bash
   python train_and_evaluate.py
   ```
   This will train a RandomForest model and save `saved_model.joblib`.

3. Run Streamlit app (optional):
   ```bash
   streamlit run streamlit_app.py
   ```

---

## Report (summary)
- Methodology: Data preprocessing (drop/replace missing), encoding categorical features, train/test split, RandomForestRegressor, evaluation using MAE/RMSE/R2, feature importance, fairness checks.
- Results: Example metrics printed after training. Feature importance plotted in the script.
- Future work: Add explainability (SHAP), integrate into HR systems, more features (performance ratings, department), advanced fairness mitigation.

