# train_and_evaluate.py
# Train models on the sample dataset and save the best model.

import pandas as pd
import numpy as np
import joblib
from pathlib import Path
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib.pyplot as plt

DATA_PATH = Path("employee_salary_data.csv")
MODEL_PATH = Path("saved_model.joblib")

def load_data(path=DATA_PATH):
    df = pd.read_csv(path)
    return df

def preprocess_and_split(df):
    # Basic cleaning: drop rows with missing target
    df = df.dropna(subset=["Salary"]).copy()
    # Fill or drop other missing values (simple approach)
    df = df.fillna({"Skills_Score": df["Skills_Score"].median(),
                    "Communication_Score": df["Communication_Score"].median()})
    # Features and target
    X = df[["Experience","Education","Role","Skills_Score","Communication_Score","Location"]]
    y = df["Salary"]
    # Train test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    return X_train, X_test, y_train, y_test

def build_pipeline():
    # categorical and numerical features
    cat_features = ["Education","Role","Location"]
    num_features = ["Experience","Skills_Score","Communication_Score"]

    # Preprocessing for numerical data
    num_transformer = StandardScaler()

    # Preprocessing for categorical data
    cat_transformer = OneHotEncoder(handle_unknown="ignore", sparse=False)

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", num_transformer, num_features),
            ("cat", cat_transformer, cat_features),
        ],
        remainder="drop"
    )

    model = RandomForestRegressor(n_estimators=100, random_state=42)

    pipeline = Pipeline(steps=[("preprocessor", preprocessor),
                               ("model", model)])
    return pipeline

def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = mean_squared_error(y_test, y_pred, squared=False)
    r2 = r2_score(y_test, y_pred)
    print(f"MAE: {mae:.2f}")
    print(f"RMSE: {rmse:.2f}")
    print(f"R2: {r2:.3f}")
    return y_pred

def plot_feature_importance(pipeline, X_train):
    # Extract feature importances from RandomForest in pipeline
    model = pipeline.named_steps["model"]
    preprocessor = pipeline.named_steps["preprocessor"]
    # get feature names after one-hot encoding
    cat_cols = preprocessor.named_transformers_["cat"].get_feature_names_out(["Education","Role","Location"])
    feature_names = list(["Experience","Skills_Score","Communication_Score"]) + list(cat_cols)
    importances = model.feature_importances_
    # plot
    plt.figure(figsize=(8,6))
    idx = np.argsort(importances)[::-1][:20]
    plt.barh([feature_names[i] for i in idx[::-1]], importances[idx[::-1]])
    plt.xlabel("Importance")
    plt.title("Feature Importances")
    plt.tight_layout()
    plt.savefig("feature_importance.png")
    print("Saved feature_importance.png")

def main():
    df = load_data()
    X_train, X_test, y_train, y_test = preprocess_and_split(df)
    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)
    # Save model
    joblib.dump(pipeline, MODEL_PATH)
    print(f"Saved model to {MODEL_PATH}")
    # Evaluate
    evaluate_model(pipeline, X_test, y_test)
    # Plot feature importance
    plot_feature_importance(pipeline, X_train)

if __name__ == "__main__":
    main()
